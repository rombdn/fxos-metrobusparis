fxos-metrobusparis
==================

Web Paris transports (metro & bus) route planner using the output of `ratp-gtfs-to-json` http://github.com/rombdn/ratp-gtfs-to-json


Demo
-------

*Work in progress...*


Licence
--------

(c) 2013 Romain BEAUDON This code may be freely distributed under the terms of the GPL3 Licence